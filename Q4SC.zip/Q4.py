import os

bytes = "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00"
byte_array = bytearray.fromhex(bytes)
file_name = input("Enter path for file for shred")
print(bytearray)
print(file_name)
f = open(file_name,'wb')
f.write(byte_array);
f.close()
os.rename(file_name,'E:/abcd')
os.unlink('E:/abcd')
print(file_name + " shredded successfully")
